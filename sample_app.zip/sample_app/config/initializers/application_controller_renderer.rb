# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'eb55d61bb3dcb022f906fadd679d8eb435f99c5621273743652f391bd81dfd11c65e3aa76d29dd3ec5b63923a5e92718dbeb7403173409585259b0b631f71d58'
